
function Contato() {
  return (
    <>
      <h1>Entre em Contato</h1>

      <p>Fique à vontade para entrar em contato comigo!</p>

      <p>E-mail: ao165676@gmail.com</p>

      <p>WhatsApp: (48) 99156-1346</p>
    </>
  );
}

export default Contato;
